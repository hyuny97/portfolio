# 강승현 포트폴리오 (GitHub Pages 배포 안내)

1) GitHub에서 새 리포지토리 생성 (예: portfolio)
2) 이 폴더 파일 전체 업로드
3) Settings → Pages → Source: Deploy from a branch → main 선택
4) https://<사용자명>.github.io/<리포지토리명>/ 에서 공개 확인
